Todas las funciones han sido completadas
Se puede comprobar su funcionamiento ejecutando los ejercicios de prueba
Compilar con make all, ejecutar con los argumentos del documento de práctica o cualesquiera
