"make all" compila lex.yy.c y crea el ejecutable pruebaMorfo
"make ejemploi", con i el numero de ejemplo, crea la salida 
    en base a ejemplos/entradai.txt y hace diff con su salida esperada
"make compare_ejemplos" crea todos los ejemplos y los compara con sus salidas