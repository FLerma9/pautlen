"make all" compila flex y bison y crea el ejecutable pruebaSintactico
"make ejemploi", con i el numero de ejemplo, crea la salida 
    en base a ejemplos/entrada_sin_i.txt y hace diff con su salida esperada
"make compare_ejemplos" crea todos los ejemplos y los compara con sus salidas